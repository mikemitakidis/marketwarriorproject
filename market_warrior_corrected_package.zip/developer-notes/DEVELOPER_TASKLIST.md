# Market Warrior - Developer Task List (Priority Order)

## P0 - Launch blockers (security + anti-cheat)
1. Server-side quiz validation (never expose correct answers; score on server; 60% pass)
2. Server-time unlock logic (dashboard/day use server status; prevent clock cheating)
3. Protect content behind auth + entitlement + unlocked-day check
4. Stripe checkout + webhook hardening (validate expected price/amount; grant access only after webhook)
5. Remove secret fallbacks; enforce env vars; no service key in client
6. Fix database/RLS so students cannot read course_content/quiz_questions directly

## P1 - MVP flow
7. Dynamic day template (Day X)
8. Task submission endpoint + Supabase Storage
9. Terms acceptance persistence (no re-accept on re-login)
10. Certificate generation endpoint + protected certificate page

## P2 - Master Admin Panel (CMS + CRM)
11. Admin authentication/authorization (is_admin gate)
12. Settings CRUD (price/access duration/max devices/support email/logo)
13. Content editor + preview + quiz editor + task editor
14. User CRM actions (unlock, reset devices, extend access, ban, refund)
15. Promo codes + validation server-side

## P3 - Automation / growth
16. Journal lead magnet + nurture emails
17. Purchase + unlock + inactivity emails
18. Affiliate dashboard + commissions; payouts later
