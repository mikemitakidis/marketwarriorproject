# Market Warrior - GitHub Upload Guide (no coding required)

Goal: put *all* project inputs (specs, templates, content, Supabase exports, and the latest code snapshot) in one GitHub repo so a new developer can onboard fast.

## 1) Create folders (recommended)
Create these folders in your repo:

- docs/specs/
- docs/handoff/
- assets/branding/
- templates/html/
- content/days-zips/
- supabase/exports/
- supabase/migrations/
- archive/zips/
- developer-notes/

Tip: in GitHub, you can create a folder by creating a file inside it, for example:
`docs/specs/.keep`

## 2) Upload files
Use **Add file -> Upload files** and upload:

- Proposal + Technical Spec + Admin specs into `docs/specs/`
- The handoff pack (PDF/DOCX) into `docs/handoff/`
- Your HTML templates into `templates/html/`
- Day content ZIPs into `content/days-zips/`
- Supabase CSV exports into `supabase/exports/`
- Code ZIP snapshots into `archive/zips/`

## 3) IMPORTANT - do not upload secrets
Never upload:
- any .env files with real keys
- screenshots showing secret keys
- SUPABASE_SERVICE_KEY or STRIPE_SECRET_KEY in any text file

Instead, keep `.env.example` only (placeholders).

## 4) Optional - create a GitHub Release
Create a Release named `handoff-v2` and attach the full bundle ZIP so the developer can download everything in one click.
