-- Market Warrior - Supabase schema (starter) 
-- Apply in a NEW Supabase project (recommended) using the SQL Editor.
-- IMPORTANT: This is a baseline. Developer should review and adjust to match final code.

create extension if not exists "pgcrypto";

-- 1) User profile (1:1 with auth.users)
create table if not exists public.user_profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique not null references auth.users(id) on delete cascade,
  email text not null,
  full_name text,
  has_paid boolean not null default false,
  payment_status text not null default 'free', -- free, paid, refunded
  amount_paid numeric,
  payment_date timestamptz,
  stripe_customer_id text,
  stripe_session_id text,
  access_expires_at timestamptz,
  challenge_start_date timestamptz,
  agreed_to_terms boolean not null default false,
  agreement_date timestamptz,
  is_admin boolean not null default false,
  device_ids text[] not null default '{}'::text[],
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 2) Course content (admin-managed; NOT readable directly by client)
create table if not exists public.course_content (
  id uuid primary key default gen_random_uuid(),
  day_number integer not null unique check (day_number between 1 and 30),
  title text not null,
  subtitle text,
  content_html text,
  youtube_video_id text,
  task_description text,
  task_steps jsonb,
  is_published boolean not null default true,
  next_preview text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 3) Quiz questions (admin-managed; do not expose correct_answer via client reads)
create table if not exists public.quiz_questions (
  id uuid primary key default gen_random_uuid(),
  day_number integer not null check (day_number between 1 and 30),
  question_order integer,
  question text not null,
  options jsonb not null,
  correct_answer integer not null,
  explanation text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 4) Progress (single source of truth)
create table if not exists public.challenge_progress (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  day_number integer not null check (day_number between 1 and 30),
  unlocked boolean not null default false,
  unlocked_at timestamptz,
  quiz_passed boolean not null default false,
  quiz_score integer,
  quiz_completed_at timestamptz,
  task_completed boolean not null default false,
  task_submitted_at timestamptz,
  completed boolean not null default false,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(user_id, day_number)
);

-- 5) Quiz results (attempts)
create table if not exists public.quiz_results (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  day_number integer not null check (day_number between 1 and 30),
  answers jsonb,
  score integer not null,
  passed boolean not null,
  correct_count integer,
  total_questions integer,
  completed_at timestamptz not null default now()
);

-- 6) Task submissions
create table if not exists public.task_submissions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  day_number integer not null check (day_number between 1 and 30),
  task_text text,
  file_url text,
  submitted_at timestamptz not null default now()
);

-- 7) Promo codes (server-validated only)
create table if not exists public.promo_codes (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  discount_percent integer not null check (discount_percent between 1 and 100),
  max_uses integer,
  current_uses integer not null default 0,
  expires_at timestamptz,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 8) Payments (server-only writes)
create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  email text not null,
  amount numeric not null,
  currency text,
  status text,
  stripe_session_id text,
  stripe_customer_id text,
  stripe_payment_intent text,
  referral_code text,
  created_at timestamptz not null default now()
);

-- 9) Referrals/affiliates tracking (baseline)
create table if not exists public.referrals (
  id uuid primary key default gen_random_uuid(),
  referrer_user_id uuid references auth.users(id) on delete set null,
  referred_email text not null,
  stripe_session_id text,
  commission_rate numeric,
  commission numeric,
  status text,
  paid_at timestamptz,
  created_at timestamptz not null default now()
);

-- 10) Announcements (readable)
create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  message text not null,
  is_active boolean not null default true,
  expires_at timestamptz,
  created_at timestamptz not null default now()
);

-- 11) Activity log (server-only writes)
create table if not exists public.activity_log (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  action text not null,
  details jsonb,
  created_at timestamptz not null default now()
);

-- 12) Site settings (key/value)
create table if not exists public.site_settings (
  id uuid primary key default gen_random_uuid(),
  setting_key text not null unique,
  setting_value text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- RLS
alter table public.user_profiles enable row level security;
alter table public.course_content enable row level security;
alter table public.quiz_questions enable row level security;
alter table public.challenge_progress enable row level security;
alter table public.quiz_results enable row level security;
alter table public.task_submissions enable row level security;
alter table public.promo_codes enable row level security;
alter table public.payments enable row level security;
alter table public.referrals enable row level security;
alter table public.announcements enable row level security;
alter table public.activity_log enable row level security;
alter table public.site_settings enable row level security;

-- Policies: student can access ONLY own data for progress/results/submissions/profile
create policy "user_profiles_select_own" on public.user_profiles
  for select to authenticated
  using (auth.uid() = user_id);

create policy "user_profiles_update_own" on public.user_profiles
  for update to authenticated
  using (auth.uid() = user_id);

create policy "challenge_progress_own" on public.challenge_progress
  for all to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

create policy "quiz_results_own" on public.quiz_results
  for all to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

create policy "task_submissions_own" on public.task_submissions
  for all to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- Announcements: readable publicly
create policy "announcements_public_read_active" on public.announcements
  for select to public
  using (is_active = true and (expires_at is null or expires_at > now()));

-- Everything else (content, quiz_questions, promo_codes, payments, referrals, activity_log, site_settings)
-- intentionally has NO public/authenticated policies: only server (service role) should access.
